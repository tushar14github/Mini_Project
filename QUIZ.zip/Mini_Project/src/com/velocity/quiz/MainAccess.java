package com.velocity.quiz;

public class MainAccess {

	public static void main(String[] args) throws Exception {
		
		Question question = new Question();
			question.getQuestion();
			Result.getResult();
		

	}

}
