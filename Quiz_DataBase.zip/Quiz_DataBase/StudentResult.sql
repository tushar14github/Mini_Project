use miniproject;
CREATE TABLE resultInfo(
Std_Id INT NOT NULL AUTO_INCREMENT,
firstname varchar (300) DEFAULT NULL,
lastname VARCHAR  (300) DEFAULT NULL,
score INT  DEFAULT NULL,
PRIMARY KEY (Std_Id)
);
desc resultinfo;
select * from resultinfo;