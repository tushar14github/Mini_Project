use miniproject;

create table questionlist
(
id int not null auto_increment,
question varchar(300) default null,
A varchar (300) default null,
B varchar(300) default null,
C varchar (300) default null,
D varchar (300) default null,
CorrectAns varchar (300) default null,
Primary Key (id)
);

desc questionlist;
Alter table questionlist rename column id to QuestionNo;
INSERT INTO questionlist VALUES (1,'Which of the following option leads to the portability and security of Java?','Bytecode is executed by JVM','The applet makes the Java code secure and portable','Use of exception handling','Dynamic binding between objects','B'),(2,' Which package contains the Random class?','java.util package','java.lang package','java.awt package','java.io package','A'),(3,'An interface with no fields or methods is known as a ______.','Runnable Interface','Marker Interface','Abstract Interface','CharSequence Interface','B'),(4,'Which option is false about the final keyword?','A final method cannot be overridden in its subclasses.','A final class cannot be extended.','A final class cannot extend other classes.','A final method can be inherited.','C'),(5,'Which of these classes are the direct subclasses of the Throwable class?','Runtimeexception and error class','exception and VirtualMachineError class','Error and Exception class','IOexception and VirtualMachineError class','C'),(6,' Which keyword is used for accessing the features of a package?','package','import','extends','export','B'),(7,' In java, jar stands for_____.','Java Archive Runner','Java Application Resource','Java Application Runner','None of the above','D'),(8,' Which of the given methods are of Object class?','notify(), wait( long msecs ), and synchronized()','wait( long msecs ), interrupt(), and notifyAll()','notify(), notifyAll(), and wait()','sleep( long msecs ), wait(), and notify()','C'),(9,'Which of the following is a mutable class in java?','java.lang.String','java.lang.Byte','java.lang.Short','java.lang.StringBuilder','D'),(10,'What is meant by the classes and objects that dependents on each other?','Tight Coupling','Cohesion','Loose Coupling','None of the above','A');
select * from questionlist;